// search-xpath-wiki.js — Wikipedia Search Demo with Proxy Check

highlightSelectedElements = true;

logprint("=== Wikipedia XPath Search Demo ===");

// ── Step 1: Ensure proxy is working before doing anything ─────
logprint("Step 1: Checking proxy connection...");

let connected = await checkConnectedProxy();
let attempts = 0;
const MAX_ATTEMPTS = 10;

while (!connected && attempts < MAX_ATTEMPTS) {
  attempts++;
  logprint(`Proxy not working (attempt ${attempts}/${MAX_ATTEMPTS}) — switching...`);
  await changeProxy();
  await randomWait(1500, 3000); // give new proxy time to connect
  connected = await checkConnectedProxy();
}

if (!connected) {
  logprint("ERROR: Could not find a working proxy after " + MAX_ATTEMPTS + " attempts");
  await screenshot();
  return;
}

logprint("✓ Proxy connected — proceeding");

// ── Step 2: Navigate to Wikipedia ────────────────────────────
logprint("Step 2: Navigating to Wikipedia...");
await GoToURL("https://www.wikipedia.org/");
await randomWait(800, 1400);

const url = await getURL();
logprint("Current URL: " + url);

// ── Step 3: Verify search box exists, with retry ──────────────
logprint("Step 3: Waiting for search box...");
const SEARCH_INPUT  = '//input[@id="searchInput"]';
const SEARCH_BUTTON = '//button[@type="submit"]';

const found = await retry(async () => {
  return await check(SEARCH_INPUT);
}, 3);

if (!found) {
  logprint("ERROR: Search box not found after 3 attempts");
  await screenshot();
  return;
}

const inputInfo = await logElement(SEARCH_INPUT);
logprint("Search input: " + JSON.stringify(inputInfo));

// ── Step 4: Dismiss cookie banner if present ──────────────────
logprint("Step 4: Checking for cookie banner...");
await ifExists('//button[contains(text(),"Accept")]', async () => {
  logprint("Cookie banner found — dismissing...");
  await click('//button[contains(text(),"Accept")]');
  await randomWait(400, 800);
});

// ── Step 5: Move mouse naturally to search box then type ──────
logprint("Step 5: Moving mouse to search box...");
await moveMouseTo(SEARCH_INPUT);
await randomWait(200, 500);

logprint("Step 6: Typing search term...");
await fill(SEARCH_INPUT, "XPath", [80, 140]);
await randomWait(400, 900);

// ── Step 6: Screenshot before submitting ─────────────────────
logprint("Step 7: Taking screenshot before search...");
await screenshot();

// ── Step 7: Move mouse to button and click ───────────────────
logprint("Step 8: Moving mouse to search button...");
await moveMouseTo(SEARCH_BUTTON);
await randomWait(300, 600);

logprint("Step 9: Clicking search...");
await click(SEARCH_BUTTON);

// ── Step 8: Wait for results page ────────────────────────────
logprint("Step 10: Waiting for results...");
await waitForElement('//h1', 8000);
await randomWait(600, 1000);

const resultURL = await getURL();
logprint("Results URL: " + resultURL);

// ── Step 9: Extract and log results ──────────────────────────
logprint("Step 11: Extracting results...");
const RESULT_LINKS = '//div[@class="mw-search-results"]//a';

const hasResults = await check(RESULT_LINKS);
if (hasResults) {
  const results = await extractAll(RESULT_LINKS);
  logprint("Found " + results.length + " results:");
  results.slice(0, 5).forEach((r, i) => logprint(`  ${i+1}. ${r}`));
} else {
  const title = await extractText('//h1[@id="firstHeading"]');
  logprint("Landed on article: " + title);
}

// ── Step 10: Final screenshot ─────────────────────────────────
logprint("Step 12: Taking final screenshot...");
await screenshot();

logprint("=== Done ===");
