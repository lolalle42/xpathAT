// scraper.js — Hacker News top stories
logprint("Scraping Hacker News...");
await GoToURL("https://news.ycombinator.com");
const titles = await extractAll('//span[@class="titleline"]/a');
const scores = await extractAll('//span[@class="score"]');
logprint("Found " + titles.length + " stories:");
for (let i = 0; i < Math.min(8, titles.length); i++) {
  logprint((i+1) + ". " + titles[i] + (scores[i] ? " ["+scores[i]+"]" : ""));
  // script will be paused until user clicks resume button
  await PauseUntillResumed();
}
logprint("Done ✓");
