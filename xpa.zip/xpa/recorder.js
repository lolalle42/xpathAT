// recorder.js — injected as a file into the active page
(function () {
  if (window.__xpaRecActive) return;
  window.__xpaRecActive = true;
  const lines = [];

  function getXP(el) {
    if (!el || el.nodeType !== 1) return "";
    if (el.id) return `//*[@id="${el.id}"]`;
    if (el === document.body) return "//body";
    for (const a of ["name","data-testid","aria-label","placeholder","type"]) {
      const v = el.getAttribute(a);
      if (v) return `//${el.tagName.toLowerCase()}[@${a}="${v}"]`;
    }
    const sib = Array.from(el.parentNode?.children||[]).filter(s=>s.tagName===el.tagName);
    const i = sib.indexOf(el)+1;
    return `${getXP(el.parentElement)}/${el.tagName.toLowerCase()}${sib.length>1?`[${i}]`:""}`;
  }

  function push(line) {
    lines.push(line);
    browser.runtime.sendMessage({ type: "RECORDER_LINE", line });
  }

  const onCk = e => { if (e.isTrusted) push(`await click("${getXP(e.target)}");`); };
  const timers = {};
  const onIn = e => {
    if (!e.isTrusted) return;
    const xp = getXP(e.target);
    clearTimeout(timers[xp]);
    timers[xp] = setTimeout(() => push(`await fill("${xp}", ${JSON.stringify(e.target.value)});`), 700);
  };

  document.addEventListener("click", onCk, true);
  document.addEventListener("input", onIn, true);

  window.__xpaRecorderStop = () => {
    document.removeEventListener("click", onCk, true);
    document.removeEventListener("input", onIn, true);
    window.__xpaRecActive = false;
    browser.runtime.sendMessage({ type: "RECORDER_DONE", script: lines.join("\n") });
  };
})();
