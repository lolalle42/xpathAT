// sandbox.js — XPath Automator script execution engine

// ── Pause gate ────────────────────────────────────────────────
let _pausePromise  = null;
let _pauseResolver = null;
let _stopped       = false;

function _checkPause() {
  if (!_pausePromise) return Promise.resolve();
  return _pausePromise;
}

// ── Highlight flag ────────────────────────────────────────────
// User writes: highlightSelectedElements = true;
// We prepend a setter shim to the script that writes to _hl.
let _hl = false;

// ── postMessage bridge ────────────────────────────────────────
let _callId = 0;
const _pending = {};

window.addEventListener("message", (e) => {
  const msg = e.data;
  if (!msg) return;

  if (msg.__xpaReply && _pending[msg.__xpaReply]) {
    _pending[msg.__xpaReply](msg.result);
    delete _pending[msg.__xpaReply];
    return;
  }

  if (msg.__xpaStop) {
    _stopped = true;
    if (_pauseResolver) {
      const res = _pauseResolver;
      _pausePromise = null; _pauseResolver = null;
      res();
    }
    return;
  }

  if (msg.__xpaPause) {
    if (!_pausePromise) {
      _pausePromise = new Promise((res) => { _pauseResolver = res; });
      parent.postMessage({ __xpaPaused: true }, "*");
    }
    return;
  }

  if (msg.__xpaResume) {
    if (_pauseResolver) {
      const res = _pauseResolver;
      _pausePromise = null; _pauseResolver = null;
      res();
      parent.postMessage({ __xpaResumed: true }, "*");
    }
    return;
  }

  if (msg.__xpaRun) {
    _stopped = false;
    _hl = false;
    if (_pauseResolver) { _pauseResolver(); }
    _pausePromise = null; _pauseResolver = null;

    runScript(msg.code)
      .then(() => parent.postMessage({ __xpaDone: true, success: true }, "*"))
      .catch(e => {
        if (e.message === "__XPA_STOPPED__")
          parent.postMessage({ __xpaDone: true, success: true, stopped: true }, "*");
        else
          parent.postMessage({ __xpaDone: true, success: false, error: e.message }, "*");
      });
    return;
  }
});

// ── callBg — reads _hl at call time ──────────────────────────
function callBg(action, args = []) {
  if (_stopped) return Promise.reject(new Error("__XPA_STOPPED__"));
  return _checkPause().then(() => {
    if (_stopped) return Promise.reject(new Error("__XPA_STOPPED__"));
    return new Promise((resolve) => {
      const id = "c" + (++_callId);
      _pending[id] = resolve;
      parent.postMessage({ __xpaCall: true, id, action, args, hl: _hl }, "*");
    });
  });
}

function PauseUntillResumed() {
  if (!_pausePromise) {
    _pausePromise = new Promise((res) => { _pauseResolver = res; });
  }
  parent.postMessage({ __xpaPaused: true }, "*");
  return _pausePromise;
}

// ── Helpers ───────────────────────────────────────────────────
const helpers = {
  GoToURL:   (url)    => callBg("GoToURL",   [url]),
  newTab:    (url)    => callBg("newTab",    [url || "about:blank"]),
  closeTab:  ()       => callBg("closeTab",  []),
  reload:    ()       => callBg("reload",    []),
  switchTab: (tabId)  => callBg("switchTab", [tabId]),

  Wait: async (ms) => {
    let rem = ms;
    while (rem > 0) { const s = await callBg("waitChunk", [rem]); rem -= (s || 50); }
  },
  waitForElement: (xpath, timeout) => callBg("waitForElement", [xpath, timeout || 10000]),

  check:       (xpath)        => callBg("check",       [xpath]),
  click:       (xpath)        => callBg("click",       [xpath]),
  extractText: (xpath)        => callBg("extractText", [xpath]),
  extractAll:  (xpath)        => callBg("extractAll",  [xpath]),
  hover:       (xpath)        => callBg("hover",       [xpath]),
  selectOption:(xpath, value) => callBg("selectOption",[xpath, value]),
  scrollTo:    (xpath)        => callBg("scrollTo",    [xpath]),
  scrollV:     (px)           => callBg("scrollV",     [px]),  // scroll vertically by px (negative = up)
  scrollH:     (px)           => callBg("scrollH",     [px]),  // scroll horizontally by px (negative = left)
  getAttribute:(xpath, attr)  => callBg("getAttribute",[xpath, attr]),
  getCoords:   (xpath)        => callBg("getCoords",   [xpath]),

  fill: async (xpath, value, delay) => {
    const text = String(value);
    await callBg("clearField", [xpath]);
    for (const ch of text) {
      await callBg("typeChar", [xpath, ch]);
      const ms = Array.isArray(delay)
        ? delay[0] + Math.random() * (delay[1] - delay[0])
        : (delay !== undefined ? delay : 80);
      let rem = ms;
      while (rem > 0) { const s = await callBg("waitChunk", [rem]); rem -= (s || 50); }
    }
    return true;
  },

  logprint: (msg) => callBg("log", [String(msg), "print"]),
  log:      (msg) => callBg("log", [String(msg), "print"]),

  getFileContent:      (f)    => callBg("getFileContent",     [f]),
  getLineFileContent:  (f, l) => callBg("getLineFileContent", [f, l]),
  getCSVRow:           (f, r) => callBg("getCSVRow",          [f, r]),

  checkConnectedProxy: ()     => callBg("checkConnectedProxy", []),
  changeProxy:         ()     => callBg("changeProxy",         []),
  clearProxy:          ()     => callBg("clearProxy",          []),

  store:    (k, v) => callBg("store",    [k, v]),
  retrieve: (k)    => callBg("retrieve", [k]),

  random: (min, max) => Math.floor(Math.random() * (max - min + 1)) + min,

  getProfileName: ()     => callBg("getProfileName", []),
  setProfileName: (name) => callBg("setProfileName", [name]),

  // ── Utilities ────────────────────────────────────────────────

  // Retry any async fn up to `times` attempts, waiting 500ms between each
  retry: async (fn, times = 3) => {
    for (let i = 0; i < times; i++) {
      try {
        const result = await fn();
        if (result !== false && result !== null) return result;
      } catch (e) {
        if (i === times - 1) throw e;
      }
      await callBg("waitChunk", [500]);
    }
    return null;
  },

  // Run callback only if element exists
  ifExists: async (xpath, fn) => {
    const exists = await callBg("check", [xpath]);
    if (exists) await fn();
    return exists;
  },

  // Get current tab URL
  getURL: () => callBg("getURL", []),

  // Export data as CSV to downloads folder
  // data: array of objects, array of arrays, or raw CSV string
  exportCSV: (data, filename) => callBg("exportCSV", [data, filename || "export.csv"]),

  // Random wait between min and max ms
  randomWait: async (min, max) => {
    const ms = Math.floor(min + Math.random() * (max - min));
    let rem = ms;
    while (rem > 0) { const s = await callBg("waitChunk", [rem]); rem -= (s || 50); }
  },

  // Move mouse realistically to element then optionally click
  moveMouseTo: (xpath) => callBg("moveMouseTo", [xpath]),

  // Screenshot — saved to screenshots/[name]-[timestamp].png
  screenshot: (name) => callBg("screenshot", [name || ""]),

  // Log element details for debugging XPath selectors
  logElement: (xpath) => callBg("logElement", [xpath]),

  PauseUntillResumed,
  PauseUntilResumed: PauseUntillResumed,
};

// ── Run user script ───────────────────────────────────────────
async function runScript(code) {
  const AsyncFunction = Object.getPrototypeOf(async function(){}).constructor;

  // Replace `highlightSelectedElements = X` with a direct setter for _hl.
  // This way the user can write it like a plain variable, and it actually
  // updates the sandbox-level _hl that callBg() reads.
  const patched = code.replace(
    /highlightSelectedElements\s*=\s*(true|false)/g,
    (_, val) => `__setHL(${val})`
  );

  const fn = new AsyncFunction(
    "__setHL",          // injected setter
    ...Object.keys(helpers),
    patched
  );

  await fn(
    (v) => { _hl = !!v; },   // __setHL writes directly to sandbox _hl
    ...Object.values(helpers)
  );
}

parent.postMessage({ __xpaReady: true }, "*");
