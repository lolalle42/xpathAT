// sidebar.js

// ── Auto-reconnecting port ────────────────────────────────────
// Firefox can disconnect the port when the background goes idle.
// This wrapper transparently reconnects and re-registers listeners.
let _port = null;
const _msgListeners = [];

function getPort() {
  if (!_port) connect();
  return _port;
}

function connect() {
  _port = browser.runtime.connect({ name: "sidebar" });
  // Re-attach all registered listeners on the new port
  _msgListeners.forEach(fn => _port.onMessage.addListener(fn));
  _port.onDisconnect.addListener(() => {
    _port = null;
    // Don't reconnect immediately — let the next send() trigger it
  });
}

// Safe postMessage — reconnects automatically if port is dead
function send(msg) {
  try {
    getPort().postMessage(msg);
  } catch (e) {
    // Port was dead mid-call; reconnect and retry once
    connect();
    try { _port.postMessage(msg); } catch (_) {}
  }
}

// Register a message listener that survives reconnects
function onMsg(fn) {
  _msgListeners.push(fn);
  getPort().onMessage.addListener(fn);
}

// Initial connection
connect();

// ── Rest of setup ─────────────────────────────────────────────
const frame = document.getElementById("sandbox-frame");
frame.src = browser.runtime.getURL("sandbox.html");

let sandboxReady  = false;
let pendingCode   = null;
let recording     = false;
let scriptRunning = false;
let isPaused      = false;

// ── Pause / Resume button ─────────────────────────────────────
const btnPause = document.getElementById("btn-pause");
const btnStop  = document.getElementById("btn-stop");

function setScriptRunning(running) {
  scriptRunning = running;
  if (running) {
    isPaused = false;
    btnPause.style.display = "inline-flex";
    btnPause.classList.remove("paused");
    btnPause.textContent = "⏸ Pause";
    btnStop.style.display  = "inline-flex";
  } else {
    isPaused = false;
    btnPause.style.display = "none";
    btnPause.classList.remove("paused");
    btnPause.textContent = "⏸ Pause";
    btnStop.style.display  = "none";
  }
}

btnPause.addEventListener("click", () => {
  if (!isPaused) {
    isPaused = true;
    frame.contentWindow.postMessage({ __xpaPause: true }, "*");
    btnPause.classList.add("paused");
    btnPause.textContent = "▶ Resume";
    appendLog({ msg: "⏸ Paused — click Resume to continue", level: "warn", ts: Date.now() });
  } else {
    isPaused = false;
    frame.contentWindow.postMessage({ __xpaResume: true }, "*");
    btnPause.classList.remove("paused");
    btnPause.textContent = "⏸ Pause";
    appendLog({ msg: "▶ Resumed", level: "success", ts: Date.now() });
  }
});

btnStop.addEventListener("click", () => {
  frame.contentWindow.postMessage({ __xpaStop: true }, "*");
  appendLog({ msg: "⏹ Script stopped", level: "warn", ts: Date.now() });
  setScriptRunning(false);
});

// ── Sandbox iframe bridge ─────────────────────────────────────
window.addEventListener("message", (e) => {
  if (e.source !== frame.contentWindow) return;
  const msg = e.data;

  if (msg.__xpaReady) {
    sandboxReady = true;
    if (pendingCode) { sendToSandbox(pendingCode); pendingCode = null; }
    return;
  }

  if (msg.__xpaDone) {
    setScriptRunning(false);
    if (msg.stopped) appendLog({ msg: "⏹ Script stopped", level: "warn", ts: Date.now() });
    return;
  }

  if (msg.__xpaPaused) {
    if (!isPaused) {
      isPaused = true;
      btnPause.classList.add("paused");
      btnPause.textContent = "▶ Resume";
      appendLog({ msg: "⏸ Paused — click Resume to continue", level: "warn", ts: Date.now() });
    }
    return;
  }

  if (msg.__xpaResumed) {
    appendLog({ msg: "▶ Continuing…", level: "info", ts: Date.now() });
    return;
  }

  // Forward sandbox call to background
  send({ type: "SANDBOX_MSG", data: msg });
});

// ── Background → sidebar messages ────────────────────────────
onMsg((msg) => {
  if (msg.type === "LOG") appendLog(msg);
  if (msg.type === "RUN_IN_SANDBOX") {
    setScriptRunning(true);
    if (sandboxReady) sendToSandbox(msg.code);
    else pendingCode = msg.code;
  }
  if (msg.type === "SANDBOX_REPLY") {
    frame.contentWindow.postMessage(msg.data, "*");
  }
  if (msg.type === "RECORDER_LINE") appendRecLine(msg.line);
  if (msg.type === "RECORDER_DONE") finishRecording(msg.script);
});

// Server status dot
onMsg((msg) => {
  if (msg.type === "LOG" && msg.msg.includes("Server")) {
    document.getElementById("srv").classList.toggle("on", msg.level === "success");
  }
});

function sendToSandbox(code) {
  frame.contentWindow.postMessage({ __xpaRun: true, code }, "*");
}

// ── Tab switching ─────────────────────────────────────────────
document.querySelectorAll(".tab").forEach(t => {
  t.addEventListener("click", () => {
    document.querySelectorAll(".tab").forEach(x => x.classList.remove("active"));
    document.querySelectorAll(".panel").forEach(x => x.classList.remove("active"));
    t.classList.add("active");
    document.getElementById(`tab-${t.dataset.tab}`).classList.add("active");
  });
});

function goTab(name) {
  document.querySelector(`[data-tab="${name}"]`)?.click();
}

// ── Console logging ───────────────────────────────────────────
const ICONS = { info:"·", success:"✓", warn:"⚠", error:"✗", print:"»", debug:"…" };

function appendLog({ msg, level, ts }) {
  const el = document.getElementById("log");
  const d = document.createElement("div");
  d.className = `line ${level}`;
  const t = new Date(ts);
  const time = [t.getHours(), t.getMinutes(), t.getSeconds()]
    .map(n => String(n).padStart(2,"0")).join(":");
  d.innerHTML = `<span class="ts">${time}</span><span class="ico">${ICONS[level]||"·"}</span><span class="msg">${esc(msg)}</span>`;
  el.appendChild(d);
  el.scrollTop = el.scrollHeight;
  if (level === "error") goTab("console");
}

function esc(s) {
  return String(s).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;");
}

// ── Server dot ────────────────────────────────────────────────
document.getElementById("srv").addEventListener("click", () => send({ type: "CHECK_SERVER" }));

// ── Console bar ───────────────────────────────────────────────
document.getElementById("btn-clear").onclick = () => {
  document.getElementById("log").innerHTML = "";
};
document.getElementById("btn-proxy").onclick = () => {
  send({ type: "RUN_CODE", code: "await checkConnectedProxy();" });
  goTab("console");
};
document.getElementById("btn-qs").onclick = () => {
  const n = document.getElementById("qs").value.trim();
  if (n) { send({ type: "RUN_SCRIPT", scriptName: n }); goTab("console"); }
};
document.getElementById("qs").addEventListener("keydown", e => {
  if (e.key === "Enter") document.getElementById("btn-qs").click();
});

// ── Editor ────────────────────────────────────────────────────
document.getElementById("btn-run-ed").onclick = () => {
  const code = document.getElementById("editor").value.trim();
  if (code) { send({ type: "RUN_CODE", code }); goTab("console"); }
};
document.getElementById("btn-save-ed").onclick = async () => {
  const name = document.getElementById("ed-name").value.trim();
  const code = document.getElementById("editor").value;
  if (!name) { alert("Enter a script name first"); return; }
  try {
    const r = await fetch(`http://localhost:5000/scripts/${name}`, {
      method: "PUT", headers: { "Content-Type": "text/plain" }, body: code
    });
    appendLog({ msg: r.ok ? `Saved: ${name}` : `Save failed: ${r.status}`,
      level: r.ok ? "success" : "error", ts: Date.now() });
  } catch {
    appendLog({ msg: "Save failed — server not running", level: "error", ts: Date.now() });
  }
};
document.getElementById("editor").addEventListener("keydown", e => {
  if (e.key === "Tab") {
    e.preventDefault();
    const ta = e.target, s = ta.selectionStart;
    ta.value = ta.value.slice(0,s) + "  " + ta.value.slice(ta.selectionEnd);
    ta.selectionStart = ta.selectionEnd = s + 2;
  }
});

// ── Scripts panel ─────────────────────────────────────────────
document.getElementById("btn-refresh-scripts").onclick = loadScripts;

async function loadScripts() {
  const el = document.getElementById("script-list");
  el.innerHTML = `<div style="color:var(--muted);padding:12px;text-align:center">Loading…</div>`;
  try {
    const r = await fetch("http://localhost:5000/scripts");
    const j = await r.json();
    if (!j.scripts?.length) {
      el.innerHTML = `<div style="color:var(--muted);padding:12px;text-align:center">No scripts found</div>`;
      return;
    }
    el.innerHTML = "";
    for (const s of j.scripts) {
      const d = document.createElement("div");
      d.className = "item";
      d.innerHTML = `
        <span style="color:var(--accent);width:12px">⬡</span>
        <span class="item-name">${esc(s)}</span>
        <button class="btn btn-go" style="padding:2px 7px;font-size:9px" data-run="${esc(s)}">▶</button>
        <button class="btn" style="padding:2px 7px;font-size:9px" data-edit="${esc(s)}">✎</button>
      `;
      el.appendChild(d);
    }
    el.querySelectorAll("[data-run]").forEach(b => b.onclick = () => {
      send({ type: "RUN_SCRIPT", scriptName: b.dataset.run });
      goTab("console");
    });
    el.querySelectorAll("[data-edit]").forEach(b => b.onclick = async () => {
      try {
        const r = await fetch(`http://localhost:5000/scripts/${b.dataset.edit}`);
        document.getElementById("ed-name").value = b.dataset.edit;
        document.getElementById("editor").value = await r.text();
        goTab("editor");
      } catch {
        appendLog({ msg: `Cannot load ${b.dataset.edit}`, level: "error", ts: Date.now() });
      }
    });
  } catch {
    el.innerHTML = `<div style="color:var(--red);padding:12px;text-align:center">Server offline</div>`;
  }
}

// ── Recorder ─────────────────────────────────────────────────
const btnRec = document.getElementById("btn-rec");
btnRec.onclick = () => {
  recording = !recording;
  send({ type: "TOGGLE_RECORDER", active: recording });
  btnRec.textContent = recording ? "⏹ Stop" : "⏺ Start";
  btnRec.classList.toggle("recording", recording);
  if (recording) document.getElementById("rec-out").value = "// Recording...\n";
};
function appendRecLine(line) {
  const ta = document.getElementById("rec-out");
  ta.value += line + "\n"; ta.scrollTop = ta.scrollHeight;
}
function finishRecording(script) {
  recording = false; btnRec.textContent = "⏺ Start"; btnRec.classList.remove("recording");
  document.getElementById("rec-out").value = script;
}
document.getElementById("btn-copy-rec").onclick = () => {
  navigator.clipboard.writeText(document.getElementById("rec-out").value);
  appendLog({ msg: "Copied to clipboard", level: "success", ts: Date.now() });
};
document.getElementById("btn-rec-to-ed").onclick = () => {
  document.getElementById("editor").value = document.getElementById("rec-out").value;
  goTab("editor");
};

// ── Data panel ────────────────────────────────────────────────
document.getElementById("btn-refresh-data").onclick = loadData;

async function loadData() {
  const el = document.getElementById("data-list");
  el.innerHTML = `<div style="color:var(--muted);padding:12px;text-align:center">Loading…</div>`;
  try {
    const r = await fetch("http://localhost:5000/datasource");
    const j = await r.json();
    if (!j.files?.length) {
      el.innerHTML = `<div style="color:var(--muted);padding:12px;text-align:center">No files found</div>`;
      return;
    }
    el.innerHTML = "";
    for (const f of j.files) {
      const ext = f.split(".").pop().toLowerCase();
      const d = document.createElement("div");
      d.innerHTML = `
        <div class="item" data-file="${esc(f)}">
          <span style="color:var(--purple);width:12px">⬡</span>
          <span class="item-name">${esc(f)}</span>
          <span class="badge ${ext==="csv"?"b-purple":"b-cyan"}">${ext.toUpperCase()}</span>
          <button class="btn" style="padding:2px 7px;font-size:9px" data-preview="${esc(f)}">Preview</button>
        </div>
        <pre id="pv-${esc(f)}" style="display:none;padding:7px 10px;font-size:10px;color:var(--muted);background:var(--bg);border:1px solid var(--border);border-top:none;border-radius:0 0 5px 5px;overflow:auto;max-height:100px;white-space:pre-wrap"></pre>
      `;
      el.appendChild(d);
    }
    el.querySelectorAll("[data-preview]").forEach(b => b.onclick = async () => {
      const pv = document.getElementById(`pv-${b.dataset.preview}`);
      if (pv.style.display === "block") { pv.style.display="none"; return; }
      try {
        const r = await fetch(`http://localhost:5000/datasource/${b.dataset.preview}`);
        const txt = await r.text();
        pv.textContent = txt.slice(0,400) + (txt.length>400?"\n…":"");
        pv.style.display = "block";
      } catch { pv.textContent = "Failed to load"; pv.style.display = "block"; }
    });
  } catch {
    el.innerHTML = `<div style="color:var(--red);padding:12px;text-align:center">Server offline</div>`;
  }
}

// ── Init ─────────────────────────────────────────────────────
send({ type: "CHECK_SERVER" });
appendLog({ msg: "XPath Automator v2 ready", level: "success", ts: Date.now() });
appendLog({ msg: "Helpers: GoToURL · fill · click · extractText · Wait · PauseUntilResumed · logprint · getCSVRow · checkConnectedProxy + more", level: "info", ts: Date.now() });
