// background.js — XPath Automator core
//
// Architecture (CSP-safe):
//   1. User script code is sent to sandbox.html (an extension iframe)
//   2. sandbox.js runs it with new AsyncFunction — no page CSP applies
//   3. When helpers like click/fill are called, sandbox posts a message
//   4. background.js receives it, calls content.js in the active tab
//   5. content.js (a registered file) runs the DOM op and returns result
//   6. background.js relays result back to sandbox
//   7. All logs go to the sidebar console

const SERVER = "http://localhost:5000";

let sidebarPort   = null;   // connection from sidebar
let sandboxPort   = null;   // connection from sandbox iframe
let sandboxReady  = false;
let sandboxQueue  = [];     // scripts queued before sandbox loaded

// ── Sidebar connection ────────────────────────────────────────
browser.runtime.onConnect.addListener((port) => {
  if (port.name === "sidebar") {
    sidebarPort = port;
    port.onDisconnect.addListener(() => { sidebarPort = null; });
    port.onMessage.addListener(onSidebarMessage);
    // Sandbox messages are relayed through the sidebar's iframe postMessage bridge
  }
});

function onSidebarMessage(msg) {
  if (msg.type === "RUN_SCRIPT")       runScript(msg.scriptName);
  if (msg.type === "RUN_CODE")         dispatchToSandbox(msg.code);
  if (msg.type === "CHECK_SERVER")     checkServer();
  if (msg.type === "TOGGLE_RECORDER")  toggleRecorder(msg.active);
  // Sandbox bridge: sidebar relays postMessages from its iframe
  if (msg.type === "SANDBOX_MSG")      onSandboxMessage(msg.data);
}

// ── Proxy (mirrors the simple Proxy Switcher pattern) ────────
let currentProxy = null;

function handleProxyRequest(requestInfo) {
  if (!currentProxy) return { type: "direct" };
  return { type: "http", host: currentProxy.host, port: currentProxy.port };
}

browser.proxy.onRequest.addListener(
  handleProxyRequest,
  { urls: ["<all_urls>"] }
);

// ── Logging ───────────────────────────────────────────────────
function log(msg, level = "info") {
  postToSidebar({ type: "LOG", msg: String(msg), level, ts: Date.now() });
  console.log(`[XPA][${level}]`, msg);
}

// ── Server check ──────────────────────────────────────────────
async function checkServer() {
  try {
    const r = await fetch(`${SERVER}/ping`);
    const j = await r.json();
    log(`Server online ✓`, "success");
  } catch {
    log("Server offline — run: python server.py", "error");
  }
}

// ── Fetch and run a named script ─────────────────────────────
// params: object of extra URL params to inject as const variables
async function runScript(name, params = {}) {
  try {
    log(`Loading script: ${name}`, "info");
    const res = await fetch(`${SERVER}/scripts/${name}`);
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const code = await res.text();
    await browser.storage.local.set({ lastScript: name });
    log(`Running: ${name}`, "info");
    const preamble = buildPreamble(params);
    dispatchToSandbox(preamble + code);
  } catch (e) {
    log(`Cannot load "${name}": ${e.message}`, "error");
  }
}

// ── Build const preamble from params object ───────────────────
// Converts { profilename: "work", var1: "12" } into:
//   const profilename = "work";
//   const var1 = 12;
// Numbers are injected without quotes, everything else as strings.
function buildPreamble(params) {
  if (!params || !Object.keys(params).length) return "";
  const lines = Object.entries(params).map(([k, v]) => {
    // Sanitise key — must be a valid JS identifier
    const key = k.replace(/[^a-zA-Z0-9_$]/g, "_");
    // Auto-cast: numeric strings become numbers, "true"/"false" become booleans
    let val;
    if (v === "true")       val = "true";
    else if (v === "false") val = "false";
    else if (!isNaN(v) && v !== "") val = Number(v);
    else val = `"${String(v).replace(/"/g, '\"')}"`;
    return `var ${key} = ${val};`;
  });
  return lines.join("\n") + "\n";
}

// ── Safe post to sidebar — reconnects if port dropped ────────
function postToSidebar(msg) {
  if (sidebarPort) {
    try {
      sidebarPort.postMessage(msg);
      return;
    } catch (e) {
      sidebarPort = null;
    }
  }
  // Port is gone — nothing we can do, sandbox call will time out
  // (sidebar will reconnect on next user interaction)
}

// ── Send code to the sandbox iframe via sidebar ───────────────
function dispatchToSandbox(code) {
  if (!sidebarPort) {
    log("Sidebar not open — open the sidebar first", "error");
    return;
  }
  // Ask sidebar to forward to its sandbox iframe
  sidebarPort.postMessage({ type: "RUN_IN_SANDBOX", code });
}

// ── Handle messages from sandbox (relayed through sidebar) ────
async function onSandboxMessage(msg) {
  if (!msg) return;

  // Sandbox finished
  if (msg.__xpaDone) {
    if (msg.success) log("Script completed ✓", "success");
    else log(`Script error: ${msg.error}`, "error");
    return;
  }

  // Sandbox calling a helper
  if (msg.__xpaCall) {
    const { id, action, args, hl } = msg;
    let result = null;
    try {
      result = await dispatchHelper(action, args, hl);
    } catch (e) {
      log(`Helper error [${action}]: ${e.message}`, "error");
    }
    // Reply back to sandbox through sidebar
    // Use a helper that retries connection if port dropped during the async await above
    postToSidebar({ type: "SANDBOX_REPLY", data: { __xpaReply: id, result } });
  }
}

// ── Route helper calls ────────────────────────────────────────
async function dispatchHelper(action, args, hl = false) {
  switch (action) {

    // Logging
    case "log": {
      const [msg, level] = args;
      log(msg, level || "print");
      return null;
    }

    // Navigation
    case "GoToURL": {
      const [url] = args;
      const [tab] = await browser.tabs.query({ active: true, currentWindow: true });
      log(`GoToURL: ${url}`, "info");
      await browser.tabs.update(tab.id, { url });
      await waitForTabLoad(tab.id);
      await sleep(600);
      return null;
    }

    case "newTab": {
      const [url] = args;
      const tab = await browser.tabs.create({ url: url || "about:blank" });
      log(`New tab: ${tab.id}`, "info");
      await waitForTabLoad(tab.id);
      return tab.id;
    }

    case "closeTab": {
      const [tab] = await browser.tabs.query({ active: true, currentWindow: true });
      await browser.tabs.remove(tab.id);
      log("Tab closed", "info");
      return null;
    }

    case "reload": {
      const [tab] = await browser.tabs.query({ active: true, currentWindow: true });
      await browser.tabs.reload(tab.id);
      await waitForTabLoad(tab.id);
      log("Tab reloaded", "info");
      return null;
    }

    case "switchTab": {
      const [tabId] = args;
      // tabId can be a numeric tab ID or a 1-based index
      let target;
      if (typeof tabId === "number" && tabId < 1000) {
        // Treat small numbers as 1-based index among current window tabs
        const allTabs = await browser.tabs.query({ currentWindow: true });
        allTabs.sort((a, b) => a.index - b.index);
        target = allTabs[tabId - 1];
        if (!target) throw new Error(`No tab at index ${tabId}`);
      } else {
        // Treat as a real tab ID
        target = await browser.tabs.get(tabId);
      }
      await browser.tabs.update(target.id, { active: true });
      log(`Switched to tab ${target.id}: ${target.url}`, "info");
      return target.id;
    }

    // Timing — sleep one chunk (50ms), sandbox loops to respect pause/stop
    case "waitChunk": {
      const [ms] = args;
      await sleep(Math.min(ms, 50));
      return Math.min(ms, 50); // return how many ms were actually slept
    }

    case "waitForElement": {
      const [xpath, timeout] = args;
      const start = Date.now();
      log(`Waiting for: ${xpath}`, "info");
      while (Date.now() - start < (timeout || 10000)) {
        const found = await xpOp("check", xpath);
        if (found) { log(`Element found: ${xpath}`, "success"); return true; }
        await sleep(300);
      }
      log(`Timeout waiting for: ${xpath}`, "warn");
      return false;
    }

    // XPath DOM ops → content.js (hl flag passed through to highlight elements)
    case "clearField":   return xpOp("clearField",   args[0], args[1], undefined, hl);
    case "typeChar":     return xpOp("typeChar",     args[0], args[1], undefined, hl);
    case "check":        return xpOp("check",        args[0], undefined, undefined, hl);
    case "fill":         return xpOp("fill",         args[0], args[1], args[2],    hl);
    case "click":        return xpOp("click",        args[0], undefined, undefined, hl);
    case "extractText":  return xpOp("extractText",  args[0], undefined, undefined, hl);
    case "extractAll":   return xpOp("extractAll",   args[0], undefined, undefined, hl);
    case "hover":        return xpOp("hover",        args[0], undefined, undefined, hl);
    case "selectOption": return xpOp("selectOption", args[0], args[1],   undefined, hl);
    case "scrollTo":     return xpOp("scrollTo",     args[0], undefined, undefined, hl);
    case "scrollV":      return xpOp("scrollV",      undefined, args[0]);
    case "scrollH":      return xpOp("scrollH",      undefined, args[0]);
    case "getAttribute": return xpOp("getAttribute", args[0], args[1],   undefined, hl);
    case "getCoords":    return xpOp("getCoords",    args[0], undefined, undefined, hl);
    case "moveMouseTo":  return xpOp("moveMouseTo",  args[0], undefined, undefined, hl);
    case "logElement":   return xpOp("logElement",   args[0], undefined, undefined, hl);

    case "getURL": {
      const [tab] = await browser.tabs.query({ active: true, currentWindow: true });
      return tab.url;
    }

    case "screenshot": {
      try {
        const [name] = args;
        const [tab] = await browser.tabs.query({ active: true, currentWindow: true });
        const dataUrl = await browser.tabs.captureVisibleTab(tab.windowId, { format: "png" });
        const ts = new Date().toISOString().replace(/[:.]/g, "-").slice(0, 19);
        const prefix = name ? String(name).replace(/[^a-z0-9_-]/gi, "") : "screenshot";
        const filename = `${prefix}-${ts}.png`;
        const res = await fetch(`${SERVER}/screenshots/${filename}`, {
          method:  "PUT",
          headers: { "Content-Type": "application/json" },
          body:    JSON.stringify({ dataUrl })
        });
        if (!res.ok) throw new Error(`Server error ${res.status}`);
        log(`Screenshot saved: screenshots/${filename}`, "success");
        return filename;
      } catch (e) {
        log(`Screenshot error: ${e.message}`, "error");
        return null;
      }
    }

    case "exportCSV": {
      try {
        const [data, filename = "export.csv"] = args;

        // Build CSV string from array of objects, array of arrays, or raw string
        let csv = "";
        if (typeof data === "string") {
          csv = data;
        } else if (Array.isArray(data) && data.length) {
          if (Array.isArray(data[0])) {
            csv = data.map(row =>
              row.map(v => `"${String(v ?? "").replace(/"/g, '""')}"`).join(",")
            ).join("\n");
          } else {
            const headers = Object.keys(data[0]);
            const rows    = data.map(obj =>
              headers.map(h => `"${String(obj[h] ?? "").replace(/"/g, '""')}"`).join(",")
            );
            csv = [headers.join(","), ...rows].join("\n");
          }
        }

        const safeFilename = filename.endsWith(".csv") ? filename : filename + ".csv";

        // Save via Flask server — stored in downloads/ folder (same root as datasource/)
        const res = await fetch(`${SERVER}/downloads/${safeFilename}`, {
          method:  "PUT",
          headers: { "Content-Type": "text/plain" },
          body:    csv
        });
        if (!res.ok) throw new Error(`Server error ${res.status}`);

        log(`CSV saved: downloads/${safeFilename}`, "success");
        return safeFilename;
      } catch (e) {
        log(`exportCSV error: ${e.message}`, "error");
        return null;
      }
    }

    // Data sources
    case "getFileContent": {
      const [fileName] = args;
      const res = await fetch(`${SERVER}/datasource/${fileName}`);
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      return await res.text();
    }

    case "getLineFileContent": {
      const [fileName, lineNum] = args;
      const res = await fetch(`${SERVER}/datasource/${fileName}/line/${lineNum}`);
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const j = await res.json();
      return j.line;
    }

    case "getCSVRow": {
      const [fileName, rowNum] = args;
      const res = await fetch(`${SERVER}/datasource/${fileName}/csv/${rowNum}`);
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const j = await res.json();
      return j.row;
    }

    // Proxy check — fetch goes through active proxy (set via onRequest listener)
    case "checkConnectedProxy": {
      try {
        const r = await fetch("https://duckduckgo.com", { method: "HEAD", cache: "no-cache" });
        log(`Proxy: connected (${r.status})`, "success");
        return true;
      } catch {
        log("Proxy: not connected", "warn");
        return false;
      }
    }

    // Change proxy — reads proxies.csv, picks at random, sets _activeProxy
    // onRequest listener above picks it up immediately for all subsequent requests
    case "changeProxy": {
      try {
        const res = await fetch(`${SERVER}/datasource/proxies.csv`);
        if (!res.ok) throw new Error("proxies.csv not found in datasource/");
        const text = await res.text();

        const proxies = text
          .split("\n")
          .map(l => l.trim())
          .filter(l => l && !l.startsWith("#"))
          .map(l => {
            const parts = l.split(",");
            return { host: parts[0]?.trim(), port: parseInt(parts[1]?.trim(), 10) };
          })
          .filter(p => p.host && p.port);

        if (!proxies.length) throw new Error("No valid proxies found in proxies.csv");

        const pick = proxies[Math.floor(Math.random() * proxies.length)];
        currentProxy = { host: pick.host, port: pick.port };

        log(`Proxy changed to ${pick.host}:${pick.port}`, "success");
        return { host: pick.host, port: pick.port };

      } catch (e) {
        log(`changeProxy error: ${e.message}`, "error");
        return null;
      }
    }

    // Clear proxy — restore direct connection
    case "clearProxy": {
      currentProxy = null;
      log("Proxy cleared — direct connection", "info");
      return true;
    }

    // Storage
    case "store": {
      const [key, value] = args;
      await browser.storage.local.set({ [key]: value });
      return null;
    }
    case "retrieve": {
      const [key] = args;
      const data = await browser.storage.local.get(key);
      return data[key] ?? null;
    }

    // Profile name — pure JS WebExtension, no Python
    case "getProfileName": {
      // Firefox WebExtension APIs do NOT expose the profile name/path directly.
      // Strategy:
      //   1. Return user-saved name (set via setProfileName)
      //   2. Fall back to a unique identifier derived from the extension UUID
      //      (same UUID = same profile, so it's a stable per-profile identifier)
      const saved = await browser.storage.local.get("__profileName");
      if (saved.__profileName) return saved.__profileName;
      // Derive a short stable ID from the extension's UUID
      // moz-extension://<uuid>/ — uuid is unique per profile install
      const extUrl = browser.runtime.getURL("");
      const uuid = extUrl.split("://")[1]?.split("/")[0] || "";
      // Return last 8 chars as a short fingerprint
      return uuid ? "profile-" + uuid.slice(-8) : null;
    }

    case "setProfileName": {
      const [name] = args;
      await browser.storage.local.set({ "__profileName": name });
      log(`Profile name set to: ${name}`, "success");
      return name;
    }

    default:
      log(`Unknown helper: ${action}`, "warn");
      return null;
  }
}

// ── Send XPath op to content.js in active tab ─────────────────
async function xpOp(action, xpath, value, delay, hl = false) {
  const [tab] = await browser.tabs.query({ active: true, currentWindow: true });
  // Ensure content script is alive (auto-injected by manifest, but just in case)
  try {
    await browser.tabs.sendMessage(tab.id, { type: "XPA_PING" });
  } catch {
    await browser.tabs.executeScript(tab.id, { file: "content.js" });
    await sleep(150);
  }
  const msg = { type: "XPA_OP", action, xpath, value: value ?? null, hl: hl };
  if (delay !== undefined) msg.delay = delay;
  const resp = await browser.tabs.sendMessage(tab.id, msg);
  return resp?.result ?? null;
}

// ── Utilities ─────────────────────────────────────────────────
function sleep(ms) {
  return new Promise(r => setTimeout(r, ms));
}

function waitForTabLoad(tabId) {
  return new Promise((resolve) => {
    function listener(id, info) {
      if (id === tabId && info.status === "complete") {
        browser.tabs.onUpdated.removeListener(listener);
        resolve();
      }
    }
    browser.tabs.onUpdated.addListener(listener);
    setTimeout(resolve, 10000); // fallback
  });
}

// ── http://xpa.local/ intercept ──────────────────────────────
// Catches requests to http://xpa.local/?m=script.js
// Lets you launch scripts from CLI:
//   firefox.exe -P myprofile -no-remote "http://xpa.local/?m=wiki.js"
browser.webRequest.onBeforeRequest.addListener(
  (details) => {
    try {
      const u = new URL(details.url);
      // Match any request to xpa.local (http or https)
      if (u.hostname !== "xpa.local") return {};

      const scriptName = u.searchParams.get("m") || u.searchParams.get("script");
      if (scriptName) {
        const clean = scriptName.replace(/^["']|["']$/g, "").trim();

        // Collect all params except m/script as injectable variables
        const params = {};
        for (const [k, v] of u.searchParams.entries()) {
          if (k === "m" || k === "script") continue;
          params[k] = v.replace(/^["']|["']$/g, ""); // strip surrounding quotes
        }

        if (Object.keys(params).length) {
          log(`XPA params: ${JSON.stringify(params)}`, "info");
        }
        log(`XPA trigger: ${clean}`, "info");

        // Small delay so the sidebar has time to connect before we run
        setTimeout(() => {
          runScript(clean, params);
          // Close the trigger tab — it served its purpose
          browser.tabs.query({ url: "http://xpa.local/*" }).then(tabs => {
            tabs.forEach(t => browser.tabs.remove(t.id));
          });
        }, 800);
      }

      // Block the request — xpa.local doesn't exist on the network
      return { cancel: true };
    } catch {
      return {};
    }
  },
  { urls: ["http://xpa.local/*", "https://xpa.local/*"] },
  ["blocking"]
);

// ── Recorder ─────────────────────────────────────────────────
async function toggleRecorder(active) {
  const [tab] = await browser.tabs.query({ active: true, currentWindow: true });
  if (active) {
    await browser.tabs.executeScript(tab.id, { file: "recorder.js" });
    log("Recorder started", "info");
  } else {
    await browser.tabs.executeScript(tab.id, {
      code: `window.__xpaRecorderStop && window.__xpaRecorderStop()`
    });
    log("Recorder stopped", "info");
  }
}

browser.runtime.onMessage.addListener((msg) => {
  if ((msg.type === "RECORDER_LINE" || msg.type === "RECORDER_DONE") && sidebarPort) {
    sidebarPort.postMessage(msg);
  }
});

// ── Keyboard shortcuts ────────────────────────────────────────
browser.commands?.onCommand?.addListener((cmd) => {
  if (cmd === "open-sidebar")   browser.sidebarAction.toggle();
  if (cmd === "run-last-script") {
    browser.storage.local.get("lastScript").then(d => {
      if (d.lastScript) runScript(d.lastScript);
    });
  }
});

log("XPath Automator v2 ready", "success");

// Handle one-shot messages from popup (no persistent port)
browser.runtime.onMessage.addListener((msg) => {
  if (msg.type === "RUN_SCRIPT_BG") runScript(msg.scriptName);
  if (msg.type === "RUN_CODE_BG")   dispatchToSandbox(msg.code);
});
