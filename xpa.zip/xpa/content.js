// content.js — registered content script, injected as a FILE (CSP-safe)

(function () {
  if (window.__xpaReady) return;
  window.__xpaReady = true;

  // ── Highlight ─────────────────────────────────────────────────
  function highlight(el) {
    if (!el) return;
    // Save original only once
    if (!el.hasAttribute("data-xpa-outline")) {
      el.setAttribute("data-xpa-outline", el.style.outline || "");
      el.setAttribute("data-xpa-outline-offset", el.style.outlineOffset || "");
    }
    el.style.outline       = "2px solid #3b82f6";
    el.style.outlineOffset = "2px";
  }

  function clearHighlights() {
    document.querySelectorAll("[data-xpa-outline]").forEach(el => {
      el.style.outline       = el.getAttribute("data-xpa-outline");
      el.style.outlineOffset = el.getAttribute("data-xpa-outline-offset");
      el.removeAttribute("data-xpa-outline");
      el.removeAttribute("data-xpa-outline-offset");
    });
  }

  // ── XPath helpers ─────────────────────────────────────────────
  function one(xpath) {
    try {
      return document.evaluate(
        xpath, document, null,
        XPathResult.FIRST_ORDERED_NODE_TYPE, null
      ).singleNodeValue;
    } catch (e) { return null; }
  }

  function all(xpath) {
    try {
      const snap = document.evaluate(
        xpath, document, null,
        XPathResult.ORDERED_NODE_SNAPSHOT_TYPE, null
      );
      const out = [];
      for (let i = 0; i < snap.snapshotLength; i++) out.push(snap.snapshotItem(i));
      return out;
    } catch (e) { return []; }
  }

  // ── Keyboard simulation ───────────────────────────────────────
  function charToKey(ch) {
    const code = ch.toUpperCase().charCodeAt(0);
    const map = {
      ' ':  { key: ' ',     code: 'Space',   keyCode: 32  },
      '\n': { key: 'Enter', code: 'Enter',   keyCode: 13  },
      '\t': { key: 'Tab',   code: 'Tab',     keyCode: 9   },
      '.':  { key: '.',     code: 'Period',  keyCode: 190 },
      ',':  { key: ',',     code: 'Comma',   keyCode: 188 },
      '-':  { key: '-',     code: 'Minus',   keyCode: 189 },
      '_':  { key: '_',     code: 'Minus',   keyCode: 189 },
      '@':  { key: '@',     code: 'Digit2',  keyCode: 50  },
      '!':  { key: '!',     code: 'Digit1',  keyCode: 49  },
      '/':  { key: '/',     code: 'Slash',   keyCode: 191 },
    };
    if (map[ch]) return map[ch];
    if (code >= 65 && code <= 90)
      return { key: ch, code: 'Key' + ch.toUpperCase(), keyCode: code };
    if (ch >= '0' && ch <= '9')
      return { key: ch, code: 'Digit' + ch, keyCode: ch.charCodeAt(0) };
    return { key: ch, code: 'Key' + ch.toUpperCase(), keyCode: ch.charCodeAt(0) };
  }

  function fireKey(el, ch) {
    const { key, code, keyCode } = charToKey(ch);
    const shift = ch !== ch.toLowerCase() && ch === ch.toUpperCase();
    const opts = { key, code, keyCode, which: keyCode, charCode: keyCode,
                   bubbles: true, cancelable: true, shiftKey: shift };

    el.dispatchEvent(new KeyboardEvent('keydown',  opts));
    el.dispatchEvent(new KeyboardEvent('keypress', opts));

    const start = el.selectionStart ?? el.value.length;
    const end   = el.selectionEnd   ?? el.value.length;
    const nativeSetter =
      Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype,  'value')?.set ||
      Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype,'value')?.set;
    const newVal = el.value.slice(0, start) + ch + el.value.slice(end);
    if (nativeSetter) nativeSetter.call(el, newVal);
    else el.value = newVal;
    el.selectionStart = el.selectionEnd = start + 1;

    el.dispatchEvent(new InputEvent('input', { inputType:'insertText', data:ch, bubbles:true }));
    el.dispatchEvent(new KeyboardEvent('keyup', opts));
  }

  function clearField(el) {
    el.focus();
    const nativeSetter =
      Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype,  'value')?.set ||
      Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype,'value')?.set;
    if (nativeSetter) nativeSetter.call(el, '');
    else el.value = '';
    el.dispatchEvent(new Event('input', { bubbles: true }));
  }

  // ── Message handler ───────────────────────────────────────────
  browser.runtime.onMessage.addListener((msg, _sender, sendResponse) => {

    if (msg.type === "XPA_PING") {
      sendResponse({ ok: true });
      return true;
    }

    if (msg.type !== "XPA_OP") return;

    const { action, xpath, value, hl } = msg;
    // hl = highlight flag, passed from background per-call

    // clearField
    if (action === "clearField") {
      const el = one(xpath);
      if (!el) { sendResponse({ result: false }); return true; }
      if (hl) highlight(el);
      clearField(el);
      sendResponse({ result: true });
      return true;
    }

    // typeChar
    if (action === "typeChar") {
      const el = one(xpath);
      if (!el) { sendResponse({ result: false }); return true; }
      if (hl) highlight(el);
      fireKey(el, String(value));
      sendResponse({ result: true });
      return true;
    }

    // clearHighlights
    if (action === "clearHighlights") {
      clearHighlights();
      sendResponse({ result: true });
      return true;
    }

    // scrollV — smooth vertical scroll by px (positive = down, negative = up)
    if (action === "scrollV") {
      const px = Number(value);
      (async () => {
        const startY   = window.scrollY;
        const targetY  = startY + px;
        const duration = Math.min(1200, Math.max(400, Math.abs(px) * 0.6));
        const startTime = performance.now();
        await new Promise(resolve => {
          function step(now) {
            const progress = Math.min((now - startTime) / duration, 1);
            const ease = progress < 0.5
              ? 4 * progress * progress * progress
              : 1 - Math.pow(-2 * progress + 2, 3) / 2;
            window.scrollTo(0, startY + px * ease);
            if (progress < 1) requestAnimationFrame(step);
            else resolve();
          }
          requestAnimationFrame(step);
        });
        sendResponse({ result: true });
      })();
      return true;
    }

    // scrollH — smooth horizontal scroll by px (positive = right, negative = left)
    if (action === "scrollH") {
      const px = Number(value);
      (async () => {
        const startX   = window.scrollX;
        const duration = Math.min(1200, Math.max(400, Math.abs(px) * 0.6));
        const startTime = performance.now();
        await new Promise(resolve => {
          function step(now) {
            const progress = Math.min((now - startTime) / duration, 1);
            const ease = progress < 0.5
              ? 4 * progress * progress * progress
              : 1 - Math.pow(-2 * progress + 2, 3) / 2;
            window.scrollTo(startX + px * ease, window.scrollY);
            if (progress < 1) requestAnimationFrame(step);
            else resolve();
          }
          requestAnimationFrame(step);
        });
        sendResponse({ result: true });
      })();
      return true;
    }

    // Sync actions
    let result = null;
    try {
      switch (action) {

        case "check": {
          const el = one(xpath);
          if (hl && el) highlight(el);
          result = !!el;
          break;
        }

        case "click": {
          const el = one(xpath);
          if (!el) { result = false; break; }
          if (hl) highlight(el);
          el.click();
          result = true;
          break;
        }

        case "extractText": {
          const el = one(xpath);
          if (hl && el) highlight(el);
          result = el ? (el.innerText || el.textContent || el.value || "").trim() : null;
          break;
        }

        case "extractAll": {
          const els = all(xpath);
          if (hl) els.forEach(el => highlight(el));
          result = els.map(el => (el.innerText || el.textContent || "").trim());
          break;
        }

        case "hover": {
          const el = one(xpath);
          if (!el) { result = false; break; }
          if (hl) highlight(el);

          // Get element center coordinates
          const rect = el.getBoundingClientRect();
          const cx = Math.round(rect.left + rect.width  / 2);
          const cy = Math.round(rect.top  + rect.height / 2);
          const opts = {
            bubbles: true, cancelable: true,
            clientX: cx, clientY: cy,
            screenX: cx, screenY: cy,
          };

          // Fire full sequence on the element and all its parents
          // to trigger CSS :hover and JS hover listeners at every level
          let node = el;
          while (node && node !== document) {
            node.dispatchEvent(new MouseEvent("mouseenter", { ...opts, bubbles: false }));
            node = node.parentElement;
          }
          el.dispatchEvent(new MouseEvent("mouseover",  opts));
          el.dispatchEvent(new MouseEvent("mousemove",  opts));

          // Also set pointer coordinates on the document for sites
          // that track mouse position via document-level listeners
          document.dispatchEvent(new MouseEvent("mousemove", opts));

          result = true;
          break;
        }

        case "selectOption": {
          const el = one(xpath);
          if (!el) { result = false; break; }
          if (hl) highlight(el);
          el.value = value;
          el.dispatchEvent(new Event("change", { bubbles: true }));
          result = true;
          break;
        }

        case "scrollTo": {
          const el = one(xpath);
          if (!el) { result = false; break; }
          if (hl) highlight(el);
          el.scrollIntoView({ behavior: "smooth", block: "center" });
          result = true;
          break;
        }

        case "getAttribute": {
          const el = one(xpath);
          if (hl && el) highlight(el);
          result = el ? el.getAttribute(value) : null;
          break;
        }

        case "getCoords": {
          const el = one(xpath);
          if (!el) { result = null; break; }
          if (hl) highlight(el);
          const r = el.getBoundingClientRect();
          result = {
            // Position relative to viewport
            top:    Math.round(r.top),
            left:   Math.round(r.left),
            bottom: Math.round(r.bottom),
            right:  Math.round(r.right),
            // Center point
            x:      Math.round(r.left + r.width  / 2),
            y:      Math.round(r.top  + r.height / 2),
            // Size
            width:  Math.round(r.width),
            height: Math.round(r.height),
            // Absolute position (includes scroll offset)
            absX:   Math.round(r.left + window.scrollX),
            absY:   Math.round(r.top  + window.scrollY),
          };
          break;
        }

        case "moveMouseTo": {
          const el = one(xpath);
          if (!el) { result = false; break; }
          if (hl) highlight(el);

          const rect = el.getBoundingClientRect();
          const destX = Math.round(rect.left + rect.width  / 2);
          const destY = Math.round(rect.top  + rect.height / 2);

          // Simulate a curved path from centre of viewport to element
          const startX = Math.round(window.innerWidth  / 2);
          const startY = Math.round(window.innerHeight / 2);
          const steps  = 12;

          for (let i = 1; i <= steps; i++) {
            const t  = i / steps;
            // Slight arc via quadratic bezier control point
            const cx = startX + (destX - startX) * 0.5 + (Math.random() - 0.5) * 40;
            const cy = startY + (destY - startY) * 0.5 + (Math.random() - 0.5) * 40;
            const x  = Math.round((1-t)*(1-t)*startX + 2*(1-t)*t*cx + t*t*destX);
            const y  = Math.round((1-t)*(1-t)*startY + 2*(1-t)*t*cy + t*t*destY);
            document.dispatchEvent(new MouseEvent("mousemove", {
              bubbles: true, cancelable: true, clientX: x, clientY: y
            }));
          }

          // Final precise events on the element
          const opts = { bubbles: true, cancelable: true, clientX: destX, clientY: destY };
          let node = el;
          while (node && node !== document) {
            node.dispatchEvent(new MouseEvent("mouseenter", { ...opts, bubbles: false }));
            node = node.parentElement;
          }
          el.dispatchEvent(new MouseEvent("mouseover", opts));
          el.dispatchEvent(new MouseEvent("mousemove", opts));

          result = true;
          break;
        }

        case "logElement": {
          const el = one(xpath);
          if (!el) { result = "element not found"; break; }
          if (hl) highlight(el);
          result = {
            tag:     el.tagName.toLowerCase(),
            id:      el.id        || null,
            classes: el.className || null,
            text:    (el.innerText || el.textContent || "").trim().slice(0, 120),
            value:   el.value     || null,
            href:    el.href      || null,
            visible: el.offsetParent !== null,
            rect:    (() => {
              const r = el.getBoundingClientRect();
              return { x: Math.round(r.x), y: Math.round(r.y),
                       w: Math.round(r.width), h: Math.round(r.height) };
            })()
          };
          break;
        }
      }
    } catch (e) {
      result = null;
    }

    sendResponse({ result });
    return true;
  });

})();
