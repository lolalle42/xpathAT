#!/usr/bin/env python3
"""
XPath Automator — Flask server
Usage:  pip install flask flask-cors requests
        python server.py
"""
import csv, json, random, threading, socket
from pathlib import Path
from flask import Flask, jsonify, request, abort, Response
from flask_cors import CORS
import requests

app = Flask(__name__)
CORS(app)

BASE       = Path(__file__).parent
SCRIPTS    = BASE / "scripts"
DATASOURCE = BASE / "datasource"
SCRIPTS.mkdir(exist_ok=True)
DATASOURCE.mkdir(exist_ok=True)

# ── Active proxy state ───────────────────────────────────────────
# { "host": "1.2.3.4", "port": 8080 } or None for direct
_active_proxy = None
_proxy_lock   = threading.Lock()

def safe(base, name):
    p = (base / name).resolve()
    if not str(p).startswith(str(base.resolve())):
        abort(403)
    return p

@app.route("/ping")
def ping(): return jsonify({"status": "ok"})

# ── Scripts ─────────────────────────────────────────────────────
@app.route("/scripts")
def ls_scripts():
    return jsonify({"scripts": sorted(f.name for f in SCRIPTS.glob("*.js"))})

@app.route("/scripts/<path:name>", methods=["GET"])
def get_script(name):
    p = safe(SCRIPTS, name)
    if not p.exists(): abort(404)
    return p.read_text(), 200, {"Content-Type": "text/plain"}

@app.route("/scripts/<path:name>", methods=["PUT"])
def save_script(name):
    p = safe(SCRIPTS, name)
    p.write_text(request.get_data(as_text=True))
    return jsonify({"saved": name})

@app.route("/scripts/<path:name>", methods=["DELETE"])
def del_script(name):
    p = safe(SCRIPTS, name)
    if not p.exists(): abort(404)
    p.unlink()
    return jsonify({"deleted": name})

# ── Datasource ──────────────────────────────────────────────────
@app.route("/datasource")
def ls_data():
    return jsonify({"files": sorted(f.name for f in DATASOURCE.iterdir() if f.is_file())})

@app.route("/datasource/<path:name>")
def get_data(name):
    p = safe(DATASOURCE, name)
    if not p.exists(): abort(404)
    return p.read_text(), 200, {"Content-Type": "text/plain"}

@app.route("/datasource/<path:name>/line/<int:n>")
def get_line(name, n):
    p = safe(DATASOURCE, name)
    if not p.exists(): abort(404)
    lines = p.read_text().splitlines()
    if n < 1 or n > len(lines): abort(400)
    return jsonify({"line": lines[n-1], "total": len(lines)})

@app.route("/datasource/<path:name>/csv/<int:n>")
def get_csv_row(name, n):
    p = safe(DATASOURCE, name)
    if not p.exists(): abort(404)
    with open(p, newline="") as f:
        rows = list(csv.DictReader(f))
    if n < 1 or n > len(rows): abort(400)
    return jsonify({"row": rows[n-1], "total": len(rows)})

# ── Proxy management ─────────────────────────────────────────────
@app.route("/proxy/set", methods=["POST"])
def proxy_set():
    """Called by changeProxy() — sets which proxy to use."""
    global _active_proxy
    data = request.get_json()
    with _proxy_lock:
        _active_proxy = {"host": data["host"], "port": int(data["port"])}
    return jsonify({"ok": True, "proxy": _active_proxy})

@app.route("/proxy/clear", methods=["POST"])
def proxy_clear():
    """Called by clearProxy() — back to direct connection."""
    global _active_proxy
    with _proxy_lock:
        _active_proxy = None
    return jsonify({"ok": True})

@app.route("/proxy/current")
def proxy_current():
    with _proxy_lock:
        return jsonify({"proxy": _active_proxy})

@app.route("/proxy/check")
def proxy_check():
    """
    Check if the current proxy can reach the internet.
    Returns { connected: bool }.
    """
    with _proxy_lock:
        p = _active_proxy

    proxies = None
    if p:
        proxy_url = f"http://{p['host']}:{p['port']}"
        proxies = {"http": proxy_url, "https": proxy_url}

    try:
        r = requests.get("http://httpbin.org/ip", proxies=proxies, timeout=8)
        ip = r.json().get("origin", "unknown")
        return jsonify({"connected": True, "ip": ip, "proxy": p})
    except Exception as e:
        return jsonify({"connected": False, "error": str(e), "proxy": p})

# ── Downloads ───────────────────────────────────────────────────
DOWNLOADS = BASE / "downloads"
DOWNLOADS.mkdir(exist_ok=True)

@app.route("/downloads")
def ls_downloads():
    return jsonify({"files": sorted(f.name for f in DOWNLOADS.iterdir() if f.is_file())})

@app.route("/downloads/<path:name>", methods=["GET"])
def get_download(name):
    p = safe(DOWNLOADS, name)
    if not p.exists(): abort(404)
    return p.read_text(), 200, {"Content-Type": "text/plain"}

@app.route("/downloads/<path:name>", methods=["PUT"])
def save_download(name):
    p = safe(DOWNLOADS, name)
    new_data = request.get_data(as_text=True).strip()
    if not new_data:
        return jsonify({"saved": name, "skipped": True})
    if p.exists():
        existing = p.read_text().rstrip("\n")
        existing_lines = existing.splitlines()
        new_lines = new_data.splitlines()
        # If the first line of new data matches the header of existing file, drop it
        if existing_lines and new_lines and existing_lines[0].strip() == new_lines[0].strip():
            new_lines = new_lines[1:]
        append_data = "\n".join(new_lines).strip()
        if append_data:
            p.write_text(existing + "\n" + append_data + "\n")
        return jsonify({"saved": name, "appended": True, "path": str(p)})
    else:
        p.write_text(new_data + "\n")
        return jsonify({"saved": name, "appended": False, "path": str(p)})

@app.route("/downloads/<path:name>", methods=["DELETE"])
def del_download(name):
    p = safe(DOWNLOADS, name)
    if not p.exists(): abort(404)
    p.unlink()
    return jsonify({"deleted": name})

# ── Screenshots ─────────────────────────────────────────────────
import base64, re as _re
SCREENSHOTS = BASE / "screenshots"
SCREENSHOTS.mkdir(exist_ok=True)

@app.route("/screenshots/<path:name>", methods=["PUT"])
def save_screenshot(name):
    name = _re.sub(r"[^a-zA-Z0-9_\-.]", "", name)
    # Sanitise filename
    name = _re.sub(r"[^a-zA-Z0-9_\-.]", "", name)
    data = request.get_json()
    data_url = data.get("dataUrl", "")
    # Strip "data:image/png;base64," prefix
    if "," in data_url:
        data_url = data_url.split(",", 1)[1]
    (SCREENSHOTS / name).write_bytes(base64.b64decode(data_url))
    return jsonify({"saved": name, "path": str(SCREENSHOTS / name)})

if __name__ == "__main__":
    print(f"\n  XPath Automator Server — http://localhost:5000\n")
    app.run(host="127.0.0.1", port=5000, debug=False, threaded=True)
